
  <div class="input-field s12 m12 l12" style=" padding: 0 .0rem;">
    <footer class="page-footer #d50000 red accent-4">
      <!-- <div class="container">
          <div class="row">
            <div class="col l6 s12" style=" padding: 0 .0rem;">
              <h5 class="white-text">CaiceTravel</h5>
              <p class="grey-text text-lighten-4">Caicetravel te ofrecemos los mejores sitios turisticos de caicedonia valle .</p>
            </div>
            <div class="col l4 offset-l2 s12" style=" padding: 0 .0rem;">
              <h5 class="white-text">Links</h5>
              <ul>
                <li><a class="grey-text text-lighten-3" href="#!">Acerca de</a></li>
            
              </ul>
            </div>
          </div>
        </div> -->

      <div class="footer-copyright">
        <div class="container">
          <p class="center-align">Estamos ubicados en Avenida Bolívar, Calle 8 Norte</p>
          <p class="center-align"><b>Horario:</b> Lunes a Domingo, 8:00 AM - 10:00 PM</p>
          <p class="center-align"><b>© 2025 Copyright Todos los Derechos Reservados.</b></p>
        </div>
      </div>

    </footer>
  </div>

<!--Fin del footer-->