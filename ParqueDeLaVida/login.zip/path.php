<?php
define('BASE', rtrim(__DIR__, '/') . '/'); // Ruta base del proyecto

//RutaDinamica
// define('dirDina', BASE . 'vista/');

//recurso Funciones y Descripcion atributos de Tabla en mysql
define('dirRecursos',  'recursos/');

//cargar vista tablas, Navegacion, Pie de pagina
define('dirVista', 'vista/');

//carrito de compra
define('dirCar', 'metodosCarrito/');

//libreria pdf
define('dirPDF','TCPDF/tcpdf.php');

//Se Implementan PDFS Asi
// require_once('path.php');
// require_once(dirPDF);

//sesion
define('dirSesion','metodoSesion/');

// echo dirRecursos;
?>