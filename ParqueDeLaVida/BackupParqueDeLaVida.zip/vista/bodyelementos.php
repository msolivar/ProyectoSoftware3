<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<!-- js para mostrar la contraseña -->
<script type="text/javascript" src="js/mostrarcontraseña.js"></script>
<!-- js lista dinamica -->
<script type="text/javascript" src="js/listadinamica.js"></script>
<!-- Validamos campos de tipo input, combobox, select, entre otros -->
<script type="text/javascript" src="js/validarcampos.js"></script>
<!-- soloLetrasYNumeros -->
<script type="text/javascript" src="js/sololetrasynumeros.js"></script>